# About Fancy Bookmarks Page:
Fancy Bookmarks Page is an extension for Firefox that provides a clean and customizable full page
interface for viewing the user's bookmarks. It comes with a settings page to configure colors
and other options, aiming to provide a more useful replacement to default home pages.

# Installation:
As this extension only at the beginning stages of development, it does not currently have a version
signed by Mozilla. This will be hopefully be changing soon.

For right now, you can install the extension by downloading the source code and then selecting the
.zip file within web-ext-artifacts for the install from file option in either Firefox Nightly or
Firefox Developer. In order for this to work, the xpinstall.signature.required flag in about:config
must be set to false.

# Future Changes Roadmap:
- Ability to add / remove bookmarks and folders within webpage
- Image background support
- Website favicons for bookmarks
