Starter README
